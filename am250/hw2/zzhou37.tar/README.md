Intruction to run the two program

1. trap.f90
   gfortran trap.f90 -o trap
   ./trap low high n

2. ones.f90
   gfortran ones.f90 -o ones
   ./ones
   Note: Command line argument will be ignord
